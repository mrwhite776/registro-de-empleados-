/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package asistencia;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

/**
 * Clase para gestionar usuarios en una interfaz gráfica de Java Swing.
 */
public class GestionUsuarios extends javax.swing.JFrame {

    /**
     * Constructor que inicializa los componentes de la interfaz y carga los usuarios.
     */
    public GestionUsuarios() {
        initComponents();
        cargarUsuariosDesdeBD();
    }

    /**
     * Método para cargar los datos de los usuarios desde la base de datos y mostrarlos en la tabla.
     */
    private void cargarUsuariosDesdeBD() {
        DefaultTableModel modelo = (DefaultTableModel) jTableUsuarios.getModel();
        modelo.setRowCount(0);  // Limpia la tabla completamente

        String query = "SELECT id, nombre, correo, contraseña, Rol FROM usuarios";
        try (Connection conn = ConexionDB.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("correo"),
                    rs.getString("contraseña"),
                    rs.getString("Rol")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar los datos de los usuarios: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Método para eliminar registros asociados a un usuario en la base de datos antes de eliminar el usuario.
     * @param idUsuario El ID del usuario cuyos registros asociados deben ser eliminados.
     */
    private boolean eliminarRegistrosAsociados(int idUsuario) {
        String sql = "DELETE FROM reporte WHERE id_usuario = ?";
    try (Connection conn = ConexionDB.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setInt(1, idUsuario);
        pstmt.executeUpdate();
        return true;
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al eliminar registros asociados: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    }

    // Otros métodos y componentes de la clase...

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableUsuarios = new javax.swing.JTable();
        jGuardarUsuario = new javax.swing.JButton();
        jCancelar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jModificarUsuario = new javax.swing.JButton();
        jEliminarUsuario = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jTextFieldCorreo = new javax.swing.JTextField();
        jPasswordField = new javax.swing.JPasswordField();
        jComboBoxRol = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTableUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "nombre ", "correo", "contraseña", "Rol"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTableUsuarios);

        jGuardarUsuario.setText("Guardar");
        jGuardarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jGuardarUsuarioActionPerformed(evt);
            }
        });

        jCancelar.setText("Cancelar");
        jCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCancelarActionPerformed(evt);
            }
        });

        jLabel6.setText("Gestión de Usuarios");

        jModificarUsuario.setText("Modificar");
        jModificarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jModificarUsuarioActionPerformed(evt);
            }
        });

        jEliminarUsuario.setText("Eliminar");
        jEliminarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEliminarUsuarioActionPerformed(evt);
            }
        });

        jLabel1.setText("Nombre Completo");

        jLabel2.setText("Correo Electronico");

        jLabel3.setText("Contraseña");

        jLabel4.setText("Rol");

        jComboBoxRol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Empleado", "Administrador", " ", " " }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(215, 215, 215)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jGuardarUsuario)
                .addGap(52, 52, 52)
                .addComponent(jModificarUsuario)
                .addGap(61, 61, 61)
                .addComponent(jEliminarUsuario)
                .addGap(44, 44, 44)
                .addComponent(jCancelar)
                .addGap(55, 55, 55))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel3)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextFieldNombre)
                    .addComponent(jTextFieldCorreo)
                    .addComponent(jPasswordField)
                    .addComponent(jComboBoxRol, 0, 148, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jTextFieldNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jTextFieldCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jComboBoxRol, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jGuardarUsuario)
                    .addComponent(jCancelar)
                    .addComponent(jModificarUsuario)
                    .addComponent(jEliminarUsuario))
                .addGap(7, 7, 7))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCancelarActionPerformed
        InterfazAdministrador adminInterface = new InterfazAdministrador();
        adminInterface.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jCancelarActionPerformed

    private void jGuardarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jGuardarUsuarioActionPerformed
       String sql = "INSERT INTO usuarios (nombre, correo, contraseña, Rol) VALUES (?, ?, ?, ?)";
    
    try (Connection conn = ConexionDB.getConnection(); // Utiliza el método estático de tu clase ConexionDB
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        // Asumiendo que tienes campos de texto para nombre, correo y contraseña y un JComboBox para el rol
        pstmt.setString(1, jTextFieldNombre.getText()); // Nombre completo
        pstmt.setString(2, jTextFieldCorreo.getText()); // Correo electrónico
        pstmt.setString(3, new String(jPasswordField.getPassword())); // Contraseña
        pstmt.setString(4, jComboBoxRol.getSelectedItem().toString()); // Rol

        pstmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "Usuario guardado con éxito!");
        
        // Llamar a la función que actualiza la tabla después de agregar un usuario
        cargarUsuariosDesdeBD();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al guardar el usuario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jGuardarUsuarioActionPerformed

    private void jEliminarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEliminarUsuarioActionPerformed
         DefaultTableModel modelo = (DefaultTableModel) jTableUsuarios.getModel();
    int filaSeleccionada = jTableUsuarios.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Por favor seleccione un usuario para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    int idUsuario = Integer.parseInt(modelo.getValueAt(filaSeleccionada, 0).toString());

    // Mensaje de confirmación para eliminar el usuario y los reportes asociados
    int confirmacion = JOptionPane.showConfirmDialog(this, 
        "Al eliminar al usuario se eliminarán todos los reportes de él.\n¿Desea continuar?", 
        "Confirmar eliminación", 
        JOptionPane.YES_NO_OPTION, 
        JOptionPane.WARNING_MESSAGE);

    if (confirmacion != JOptionPane.YES_OPTION) {
        return;
    }

    // Eliminar primero los registros asociados en 'reporte'
    if (!eliminarRegistrosAsociados(idUsuario)) {
        // Si falla la eliminación de registros asociados, no proceder
        return;
    }

    // Proceder a eliminar el usuario si los registros asociados han sido eliminados
    String sql = "DELETE FROM usuarios WHERE id = ?";
    try (Connection conn = ConexionDB.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setInt(1, idUsuario);
        int filasAfectadas = pstmt.executeUpdate();

        if (filasAfectadas > 0) {
            modelo.removeRow(filaSeleccionada);
            JOptionPane.showMessageDialog(this, "Usuario y todos los reportes asociados eliminados con éxito.");
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró el usuario, no se eliminó nada.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al eliminar el usuario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jEliminarUsuarioActionPerformed

    private void jModificarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jModificarUsuarioActionPerformed
         
    int selectedRow = jTableUsuarios.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Por favor seleccione un usuario para modificar.");
        return;
    }

    String sql = "UPDATE usuarios SET nombre = ?, correo = ?, contraseña = ?, Rol = ? WHERE id = ?";

    DefaultTableModel modelo = (DefaultTableModel) jTableUsuarios.getModel();
    int idUsuario = Integer.parseInt(modelo.getValueAt(selectedRow, 0).toString()); // Asumiendo que la columna 0 tiene el ID

    try (Connection conn = ConexionDB.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, jTextFieldNombre.getText()); // Nombre completo
        pstmt.setString(2, jTextFieldCorreo.getText()); // Correo electrónico
        pstmt.setString(3, new String(jPasswordField.getPassword())); // Contraseña
        pstmt.setString(4, jComboBoxRol.getSelectedItem().toString()); // Rol
        pstmt.setInt(5, idUsuario); // ID del usuario a modificar

        pstmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "Usuario modificado con éxito!");

        // Recargar los datos en la tabla
        cargarUsuariosDesdeBD();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al modificar el usuario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jModificarUsuarioActionPerformed

    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jCancelar;
    private javax.swing.JComboBox<String> jComboBoxRol;
    private javax.swing.JButton jEliminarUsuario;
    private javax.swing.JButton jGuardarUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JButton jModificarUsuario;
    private javax.swing.JPasswordField jPasswordField;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableUsuarios;
    private javax.swing.JTextField jTextFieldCorreo;
    private javax.swing.JTextField jTextFieldNombre;
    // End of variables declaration//GEN-END:variables
}
