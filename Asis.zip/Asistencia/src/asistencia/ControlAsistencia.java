/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package asistencia;

import javax.swing.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ControlAsistencia extends JFrame {
    private JButton btnEntrada;
    private JButton btnSalida;
    private int userId;

    public ControlAsistencia(int userId) {
        this.userId = userId;
        setTitle("Control de Asistencia");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        btnEntrada = new JButton("Registrar Entrada");
        btnSalida = new JButton("Registrar Salida");

        btnEntrada.addActionListener(e -> registrarEntrada());
        btnSalida.addActionListener(e -> registrarSalida());

        panel.add(btnEntrada);
        panel.add(btnSalida);

        add(panel);
    }

    private void registrarEntrada() {
        LocalDateTime ahora = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String fechaHoraActual = ahora.format(formatter);

        try (Connection conn = ConexionDB.getConnection()) {
            String sql = "INSERT INTO asistencia (id_usuario, fecha, hora_entrada) VALUES (?, CURDATE(), CURTIME())";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Entrada registrada: " + fechaHoraActual);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void registrarSalida() {
        try (Connection conn = ConexionDB.getConnection()) {
            String sql = "UPDATE asistencia SET hora_salida = CURTIME() WHERE id_usuario = ? AND fecha = CURDATE()";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Salida registrada.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

