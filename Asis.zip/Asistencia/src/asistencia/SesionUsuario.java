/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package asistencia;

/**
 *
 * @author crust
 */
public class SesionUsuario {
    // Atributo estático para mantener la sesión del usuario
    private static int idUsuario;
    private static String nombreUsuario;

    // Constructor privado para evitar instanciación directa
    private SesionUsuario() {}

    // Método para establecer el ID del usuario cuando inicia sesión
    public static void iniciarSesion(int id, String nombre) {
        idUsuario = id;
        nombreUsuario = nombre;
    }

    // Método para obtener el ID del usuario actual
    public static int getIdUsuario() {
        return idUsuario;
    }

    // Método para obtener el nombre del usuario actual
    public static String getNombreUsuario() {
        return nombreUsuario;
    }

    // Método para cerrar la sesión
    public static void cerrarSesion() {
        idUsuario = 0;  // O algún valor que represente una sesión sin usuario
        nombreUsuario = null;
    }

    // Método para verificar si hay un usuario activo
    public static boolean haySesionActiva() {
        return idUsuario != 0;  // Asume que el ID 0 significa sin sesión activa
    }
}
