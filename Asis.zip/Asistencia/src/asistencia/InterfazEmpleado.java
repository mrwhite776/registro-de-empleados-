/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package asistencia;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class InterfazEmpleado extends javax.swing.JFrame {

    public InterfazEmpleado() {
        initComponents();
        actualizarTablaRegistros();
    }

    private int obtenerIdUsuario() {
        // Asumiendo que tienes una clase SesionUsuario que maneja la sesión del usuario actual
        return SesionUsuario.getIdUsuario();
    }

    private void actualizarTablaRegistros() {
        DefaultTableModel modelo = (DefaultTableModel) jTableRegistros.getModel();
        modelo.setRowCount(0);  // Limpiar la tabla antes de agregar nuevas filas

        String query = "SELECT * FROM asistencia";
        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Object[] fila = new Object[5];  // Ajusta esta línea según el número de columnas en tu tabla
                fila[0] = rs.getInt("id");
                fila[1] = rs.getInt("id_usuario");
                fila[2] = rs.getDate("fecha");
                fila[3] = rs.getTime("hora_entrada");
                fila[4] = rs.getTime("hora_salida");

                modelo.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar los registros: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean existeUsuario(int idUsuario) {
         System.out.println("Verificando existencia del usuario con ID: " + idUsuario);  // Debug log
    String query = "SELECT count(1) FROM usuarios WHERE id = ?";
    try (Connection conn = ConexionDB.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setInt(1, idUsuario);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            boolean exists = rs.getInt(1) > 0;
            System.out.println("Usuario existe: " + exists);  // Debug log
            return exists;
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al verificar el usuario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    return false;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jEntrada = new javax.swing.JButton();
        jSalida = new javax.swing.JButton();
        jCerrarAsistencia = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableRegistros = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jEntrada.setText("Marcar Entrada");
        jEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEntradaActionPerformed(evt);
            }
        });

        jSalida.setText("Marcar Salida");

        jCerrarAsistencia.setText("Cerrar Sesion");
        jCerrarAsistencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCerrarAsistenciaActionPerformed(evt);
            }
        });

        jLabel1.setText("Registro de Asistencia");

        jTableRegistros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "id", "id usuario", "Fecha", "Entrada", "Salida"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTableRegistros);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jEntrada)
                        .addGap(75, 75, 75)
                        .addComponent(jSalida)
                        .addGap(76, 76, 76)
                        .addComponent(jCerrarAsistencia))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCerrarAsistencia)
                    .addComponent(jSalida)
                    .addComponent(jEntrada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(9, 9, 9))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCerrarAsistenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCerrarAsistenciaActionPerformed
       Login loginInterface = new Login();
        loginInterface.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jCerrarAsistenciaActionPerformed

    private void jEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEntradaActionPerformed
      if (!SesionUsuario.haySesionActiva()) {
        JOptionPane.showMessageDialog(this, "No hay una sesión activa. Por favor, inicie sesión.", "Sesión Inactiva", JOptionPane.WARNING_MESSAGE);
        return;
    }

    LocalDate fechaActual = LocalDate.now();
    LocalTime horaEntrada = LocalTime.now();

    int idUsuario = SesionUsuario.getIdUsuario();
    if (!existeUsuario(idUsuario)) {
        JOptionPane.showMessageDialog(this, "Error: El usuario no existe en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    String insertQuery = "INSERT INTO asistencia (id_usuario, fecha, hora_entrada, hora_salida) VALUES (?, ?, ?, ?)";

    try (Connection conn = ConexionDB.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

        pstmt.setInt(1, idUsuario);
        pstmt.setDate(2, Date.valueOf(fechaActual));
        pstmt.setTime(3, Time.valueOf(horaEntrada));
        pstmt.setTime(4, null);  // Hora de salida inicialmente como null

        pstmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "Asistencia registrada correctamente.");
        actualizarTablaRegistros(); // Actualiza la tabla después de registrar la asistencia
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al registrar la asistencia: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    }//GEN-LAST:event_jEntradaActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jCerrarAsistencia;
    private javax.swing.JButton jEntrada;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton jSalida;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableRegistros;
    // End of variables declaration//GEN-END:variables
}
